#!/bin/bash

TARGET=incoming/
PROCESSED=processed/

inotifywait -m -e create -e moved_to --format "%f" $TARGET \
        | while read FILENAME
                do
			mv "$TARGET/$FILENAME" "$PROCESSED/$FILENAME"

			ORIGSIZE="$(stat "$PROCESSED/$FILENAME" --print="%s")"
                        echo "Detected $FILENAME (Size: $ORIGSIZE), moving and zipping"

			gzip -9 -f "$PROCESSED/$FILENAME"
                        
			#PROCSIZE="$(stat "${PROCESSED}/${FILENAME}.gz" --print="$s")"
			PROCSIZE=$(stat "${PROCESSED}/${FILENAME}.gz" --print='%s')
			echo "New size: $PROCSIZE"


                done
